# Stopwatch

This is a simple stopwatch library to time code execution in Python.